﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YLProjeto1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Lista 1 - Exercicio 1");
            int altura;
            int base1;
            int resultado;

            Console.Write("Digite a altura: ");
            altura = int.Parse(Console.ReadLine());
            Console.Write("Digite a base: ");
            base1 = int.Parse(Console.ReadLine());
            Console.Write("Resultado: ");
            resultado = altura * base1;

            Console.WriteLine(resultado);
            Console.ReadLine();
        }
    }
}
